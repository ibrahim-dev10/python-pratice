print("hello world")
print(5)
print("bye")
print(17*13)