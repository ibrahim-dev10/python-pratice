'''
Hey harry dont remove this line
author: harry
cource :100daysofcode
'''
print("hey i am a\"good boy\"\nand this viewer is also a good boy/girl")

# print("helll0 world")
# this is a "single line comment"
#  print("this is a print statement")
#  print("helllo world")

print("hey", 6,7, sep="~", end="009\n")
print("harry")
